var i = 0;
if ("start_watch_video" in __auto_browser_context && __auto_browser_context["start_watch_video"] == "true")
{
	window.scrollTo(0, 200);
	setTimeout(__auto_browser_obj.closeCurrentTab(), 3000 );
}
else
{
	if ("read_article_done" in __auto_browser_context && __auto_browser_context["read_article_done"] == "true")
	{
		var video_item_index = 1
		if ("video_item_index" in __auto_browser_context && __auto_browser_context["video_item_index"] != "") 
		{
			video_item_index = parseInt(video_item_index_value, 10);
		}
		__auto_browser_obj.saveContext("video_item_index", "" + (i + 1), function() {
			document.evaluate("//div[@id=\"Cd5zymfz1fzs0\"]/div[" + video_item_index + "]/div/div[@class=\"word-item\"][1]", document, null, 9, null).singleNodeValue.click();
		});
		
		if (video_item_index > 20)
		{
			__auto_browser_obj.saveContext("read_video_done", "true");
		}
	}
	else
	{
		var myVar = setInterval(scrollFunc, 100);

		function scrollFunc()
		{
			window.scrollTo(0, i*5 % 2000);
			i++;
			if (i == 1000)
			{

				clearInterval(myVar);
				__auto_browser_obj.saveContext("__close_window__", "true", function(){
					__auto_browser_obj.closeCurrentTab();
				});
				
			}
		}
	}	
}
