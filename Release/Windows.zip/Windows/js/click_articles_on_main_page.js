if ("start_watch_video" in __auto_browser_context) {
	return;
}

__auto_browser_obj.getContextValue("login", function(value) {
	if (value != "true") 
	{
		document.evaluate("//div[text()=\"我的积分\"]", document, null, 9, null).singleNodeValue.click();
		//document.evaluate("//*[@id=\"C8putwnd60vk00\"]", document, null, 9, null).singleNodeValue.click();
	} 
	else 
	{
		var word_item_index = 0
		__auto_browser_obj.getContextValue("word_item_index", function(word_item_index_value)
		{
			if (word_item_index_value != "")
			{
				word_item_index = parseInt(word_item_index_value);
			}
			if (document.evaluate("//div[@class=\"word-item\"]",document, null, 9, null).singleNodeValue == null)
			{
				document.evaluate("//div[@class=\"word-item\"]",document, null, 9, null).singleNodeValue.click();
			}

			var nodes = document.evaluate("//div[@class=\"word-item\"]",document, null, XPathResult.ANY_TYPE, null);
			var node = nodes.iterateNext();

			var i = 0
			while (node) {
				if (i > 30)
				{
					break;
				}
				if (i == word_item_index)
				{
					node.click();
					__auto_browser_obj.saveContext("word_item_index", "" + (i + 1));
					
					return;
				}
				else
				{
					node = nodes.iterateNext();
					i++;
				}
			}
			__auto_browser_obj.saveContext("read_article_done", "true");
			//document.evaluate("//div/div[@class=\"radio-div\"]/label[@class=\"radio-inline\"]", document, null, 9, null).singleNodeValue.click();
		
		})
		
	}
});