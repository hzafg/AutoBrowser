__auto_browser_obj.saveContext("login", "true", function(){
	__auto_browser_obj.closeCurrentTab()
});